Sprocket Analysis



```python
#imports
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns
import datetime as dt

```


```python
#current working directory

df=pd.read_excel("D:\Downloads\KPMG_VI_New_raw_data_update_final.xlsx")


```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Note: The data and information in this document is reflective of a hypothetical situation and client. This document is to be used for KPMG Virtual Internship purposes only.</th>
      <th>Unnamed: 2</th>
      <th>Unnamed: 3</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>KPMG Virtual Internship</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>Sprocket Central Pty Ltd Data Set</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
#df_Trans=pd.read_excel("D:\Downloads\KPMG_VI_New_raw_data_update_final.xlsx",'Transactions',header=1)..default error
df_Trans=pd.read_excel("D:\Downloads\KPMG_VI_New_raw_data_update_final.xlsx",'Transactions')
```


```python
df_Trans.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction_id</th>
      <th>product_id</th>
      <th>customer_id</th>
      <th>Recency</th>
      <th>transaction_date</th>
      <th>online_order</th>
      <th>order_status</th>
      <th>brand</th>
      <th>product_line</th>
      <th>product_class</th>
      <th>...</th>
      <th>past_3_years_bike_related_purchases</th>
      <th>DOB</th>
      <th>Age</th>
      <th>job_title</th>
      <th>job_industry_category</th>
      <th>wealth_segment</th>
      <th>deceased_indicator</th>
      <th>owns_car</th>
      <th>tenure</th>
      <th>comparisom date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>253</td>
      <td>2</td>
      <td>3123</td>
      <td>0</td>
      <td>2017-12-30</td>
      <td>0.0</td>
      <td>Approved</td>
      <td>Giant Bicycles</td>
      <td>Road</td>
      <td>low</td>
      <td>...</td>
      <td>71</td>
      <td>1976-08-17 00:00:00</td>
      <td>46.764668</td>
      <td>50.0</td>
      <td>Dental Hygienist</td>
      <td>Health</td>
      <td>High Net Worth</td>
      <td>N</td>
      <td>No</td>
      <td>2017-12-30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>411</td>
      <td>62</td>
      <td>3355</td>
      <td>0</td>
      <td>2017-12-30</td>
      <td>0.0</td>
      <td>Approved</td>
      <td>Solex</td>
      <td>Standard</td>
      <td>medium</td>
      <td>...</td>
      <td>50</td>
      <td>1990-02-19 00:00:00</td>
      <td>33.246860</td>
      <td>40.0</td>
      <td>Staff Accountant I</td>
      <td>Manufacturing</td>
      <td>Mass Customer</td>
      <td>N</td>
      <td>No</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>2</th>
      <td>497</td>
      <td>62</td>
      <td>1854</td>
      <td>0</td>
      <td>2017-12-30</td>
      <td>1.0</td>
      <td>Approved</td>
      <td>Solex</td>
      <td>Standard</td>
      <td>high</td>
      <td>...</td>
      <td>11</td>
      <td>1978-09-12 00:00:00</td>
      <td>44.693436</td>
      <td>50.0</td>
      <td>Community Outreach Specialist</td>
      <td>NaN</td>
      <td>High Net Worth</td>
      <td>N</td>
      <td>Yes</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>3</th>
      <td>606</td>
      <td>70</td>
      <td>2878</td>
      <td>0</td>
      <td>2017-12-30</td>
      <td>0.0</td>
      <td>Approved</td>
      <td>Trek Bicycles</td>
      <td>Standard</td>
      <td>high</td>
      <td>...</td>
      <td>73</td>
      <td>1985-10-31 00:00:00</td>
      <td>37.553710</td>
      <td>40.0</td>
      <td>Analog Circuit Design manager</td>
      <td>Property</td>
      <td>Mass Customer</td>
      <td>N</td>
      <td>Yes</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>4</th>
      <td>748</td>
      <td>80</td>
      <td>2865</td>
      <td>0</td>
      <td>2017-12-30</td>
      <td>1.0</td>
      <td>Approved</td>
      <td>Trek Bicycles</td>
      <td>Standard</td>
      <td>medium</td>
      <td>...</td>
      <td>11</td>
      <td>1997-12-14 00:00:00</td>
      <td>25.424942</td>
      <td>30.0</td>
      <td>Electrical Engineer</td>
      <td>Manufacturing</td>
      <td>High Net Worth</td>
      <td>N</td>
      <td>No</td>
      <td>NaT</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
#shape
df_Trans.shape

```




    (20000, 26)




```python
#info
df_Trans.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 20000 entries, 0 to 19999
    Data columns (total 26 columns):
     #   Column                               Non-Null Count  Dtype         
    ---  ------                               --------------  -----         
     0   transaction_id                       20000 non-null  int64         
     1   product_id                           20000 non-null  int64         
     2   customer_id                          20000 non-null  int64         
     3   Recency                              20000 non-null  object        
     4   transaction_date                     20000 non-null  datetime64[ns]
     5   online_order                         19640 non-null  float64       
     6   order_status                         20000 non-null  object        
     7   brand                                19803 non-null  object        
     8   product_line                         19803 non-null  object        
     9   product_class                        19803 non-null  object        
     10  product_size                         19803 non-null  object        
     11  list_price                           20000 non-null  float64       
     12  standard_cost                        19803 non-null  float64       
     13  product_first_sold_date              19803 non-null  object        
     14  Profit                               20000 non-null  float64       
     15  Gender                               20000 non-null  object        
     16  past_3_years_bike_related_purchases  20000 non-null  int64         
     17  DOB                                  20000 non-null  object        
     18  Age                                  19991 non-null  float64       
     19  job_title                            19991 non-null  float64       
     20  job_industry_category                20000 non-null  object        
     21  wealth_segment                       16768 non-null  object        
     22  deceased_indicator                   20000 non-null  object        
     23  owns_car                             20000 non-null  object        
     24  tenure                               20000 non-null  object        
     25  comparisom date                      1 non-null      datetime64[ns]
    dtypes: datetime64[ns](2), float64(6), int64(4), object(14)
    memory usage: 4.0+ MB
    


```python
df_Trans.duplicated().value_counts()
```




    False    20000
    dtype: int64




```python
df_Trans.order_status.value_counts()
```




    Approved     19821
    Cancelled      179
    Name: order_status, dtype: int64




```python
df_Trans.brand.value_counts()
```




    Solex             4253
    Giant Bicycles    3312
    WeareA2B          3295
    OHM Cycles        3043
    Trek Bicycles     2990
    Norco Bicycles    2910
    Name: brand, dtype: int64




```python
df_Trans.product_line.value_counts()
```




    Standard    14176
    Road         3970
    Touring      1234
    Mountain      423
    Name: product_line, dtype: int64




```python
df_Trans.product_class.value_counts()
```




    medium    13826
    high       3013
    low        2964
    Name: product_class, dtype: int64




```python
df_Trans.product_size.value_counts()
```




    medium    12990
    large      3976
    small      2837
    Name: product_size, dtype: int64




```python
df_Trans.list_price.hist()
```




    <Axes: >




    
![png](output_14_1.png)
    



```python
df_Trans.standard_cost.hist()
```




    <Axes: >




    
![png](output_15_1.png)
    



```python

```
